import React, { useState } from 'react';

function JobApplicationForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [coverLetter, setCoverLetter] = useState('');
  const [resume, setResume] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Create a FormData object to send the form data to the server
    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('coverLetter', coverLetter);
    if (resume) {
      formData.append('resume', resume);
    }

    // Send the form data to the server for processing
    // You can use an API endpoint to handle the form submission
    // Example: fetch('/api/apply', { method: 'POST', body: formData })
    // Handle success and error responses as needed
  };

  return (
    <div>
      <h2>Apply for the Job</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <textarea
          placeholder="Cover Letter Note"
          value={coverLetter}
          onChange={(e) => setCoverLetter(e.target.value)}
        />
        <input
          type="file"
          accept=".pdf,.doc,.docx"
          onChange={(e) => setResume(e.target.files[0])}
        />
        <button type="submit">Apply</button>
      </form>
    </div>
  );
}

export default JobApplicationForm;
