function App() {
  const isUserLoggedIn = !!localStorage.getItem('user');

  return (
    <Router>
      <div className="App">
        <Navigation />
        {isUserLoggedIn ? <p>Welcome, {JSON.parse(localStorage.getItem('user')).username}!</p> : null}
      </div>
    </Router>
  );
}
