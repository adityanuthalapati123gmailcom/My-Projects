import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Navigation from './components/Navigation';
import LandingPage from './components/LandingPage';
import JobDetails from './components/JobDetails';
import JobApplicationForm from './components/JobApplicationForm';
import SuccessPage from './components/SuccessPage';

function App() {
  return (
    <Router>
      <div className="App">
        <Navigation />
        <Switch>
          <Route path="/" exact component={LandingPage} />
          <Route path="/job/:id" component={JobDetails} />
          <Route path="/apply/:id" component={JobApplicationForm} />
          <Route path="/success" component={SuccessPage} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
