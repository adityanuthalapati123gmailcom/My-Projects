import React, { useEffect, useState } from 'react';

function JobDetails({ match }) {
  const [job, setJob] = useState({});

  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        const response = await fetch(
          `https://jobs.github.com/positions/${match.params.id}.json`
        );
        const data = await response.json();
        setJob(data);
      } catch (error) {
        console.error('Error fetching job details:', error);
      }
    };

    fetchJobDetails();
  }, [match.params.id]);

  return (
    <div>
      <h2>Job Details</h2>
      <p>Title: {job.title}</p>
      <p>Company: {job.company}</p>
      <p>Description: {job.description}</p>
      {/* Add more job details as needed */}
    </div>
  );
}

export default JobDetails;
