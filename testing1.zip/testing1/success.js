import React from 'react';

function SuccessPage({ applicationData }) {
  return (
    <div>
      <h2>Application Submitted Successfully</h2>
      <h3>Application Preview</h3>
      <p>Name: {applicationData.name}</p>
      <p>Email: {applicationData.email}</p>
      <p>Cover Letter: {applicationData.coverLetter}</p>
      <p>Resume: {applicationData.resume ? applicationData.resume.name : 'Not uploaded'}</p>
    </div>
  );
}

export default SuccessPage;
