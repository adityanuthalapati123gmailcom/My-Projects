import React, { useState } from 'react';

function LandingPage() {
  const [language, setLanguage] = useState('');
  const [jobs, setJobs] = useState([]); // To store the list of job listings

  const handleSearch = async () => {
    try {
      const response = await fetch(
        `https://jobs.github.com/positions.json?description=${language}`
      );
      const data = await response.json();
      setJobs(data);
    } catch (error) {
      console.error('Error fetching job listings:', error);
    }
  };

  return (
    <div>
      <h2>Job Portal</h2>
      <input
        type="text"
        placeholder="Enter programming language..."
        value={language}
        onChange={(e) => setLanguage(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>

      <ul>
        {jobs.map((job) => (
          <li key={job.id}>
            <p>{job.title}</p>
            <button>View Details</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default LandingPage;
