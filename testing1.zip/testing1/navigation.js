import React, { useState } from 'react';
import Login from './Login';
import Signup from './Signup';

function Navigation() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div>
      <div>
        <button onClick={() => setIsLogin(true)}>Login</button>
        <button onClick={() => setIsLogin(false)}>Signup</button>
      </div>
      {isLogin ? <Login /> : <Signup />}
    </div>
  );
}

export default Navigation;
