function Navigation() {
  const [isLogin, setIsLogin] = useState(true);

  const handleLogout = () => {
    localStorage.removeItem('user');
  };

  return (
    <div>
      <div>
        <button onClick={() => setIsLogin(true)}>Login</button>
        <button onClick={() => setIsLogin(false)}>Signup</button>
      </div>
      {localStorage.getItem('user') ? (
        <button onClick={handleLogout}>Logout</button>
      ) : null}
      {isLogin ? <Login /> : <Signup />}
    </div>
  );
}
